import React from 'react'

const Teacherhome = () => {
  return (
    <>
        <h1 className='container py-5 my-5'>Welcome to teacher home page.</h1>
    </>
  )
}

export default Teacherhome